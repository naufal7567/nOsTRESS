package org.nostress.behappy

data class ListPertanyaanK10 (
    val pertanyaan: String,
    val jawabanA: String,
    val jawabanB: String,
    val jawabanC: String,
    val jawabanD: String,
    val jawabanE: String
)